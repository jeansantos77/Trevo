import { Routes } from '@angular/router';
import { ListUserComponent } from './user/list-user/list-user.component';

export const routes: Routes = [
    { path: '', component: ListUserComponent},
    { path: 'list-user', component: ListUserComponent}
];
