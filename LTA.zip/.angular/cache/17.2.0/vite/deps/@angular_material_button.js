import {
  MAT_BUTTON_CONFIG,
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
} from "./chunk-L2WQKC2I.js";
import "./chunk-S4MYSUJ4.js";
import "./chunk-YR6Q7LWN.js";
import "./chunk-TWIYYYN4.js";
import "./chunk-G4ZQM4R6.js";
import "./chunk-4EHUQSGC.js";
import "./chunk-3QLPQU54.js";
import "./chunk-THGNCAUG.js";
import "./chunk-LEUFS2YL.js";
export {
  MAT_BUTTON_CONFIG,
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
};
//# sourceMappingURL=@angular_material_button.js.map
